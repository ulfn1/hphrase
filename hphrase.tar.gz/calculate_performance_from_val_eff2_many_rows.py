"""
MIT License

Copyright (c) 2023 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import pandas as pd
import os,sys
import math
import numpy as np

def perform_func(TN, FP, FN, TP, nrows, filename, signlevel): 
    # calculate performance

    Acc = ((TP+TN)/(TP+FP+FN+TN))
    mcc = (TP*TN-FP*FN)/math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))

    try:
        sensitivity = TP/(TP + FN)
    except:
        sensitivity = 0

    try:
        specificity = TN/(FP + TN)
    except:
        specificity = 0

    BA = (sensitivity + specificity)/2


    if nrows == 1:
        aaa =  'File\tsignlevel\tTN\tFP\tFN\tTP\tBA\tAccu\tsensitivity\tspecificity\tMCC\n'
        f.write(aaa)

    aaa = str(filename) + '\t' + str(signlevel) + '\t' + str(TN) + '\t' + str(FP) + '\t' + str(FN) + '\t' + str(TP) + '\t' + str(BA) + '\t' + str(Acc) + '\t' + str(sensitivity) + '\t' + str(specificity) + '\t' + str(mcc) + '\n'
    f.write(aaa)

    return



try:
    sys.argv[1]
except IndexError:
    print ("You need to specify a val_eff2 tab separated summary val_eff2 many files results")
    sys.exit(1)


try:
    sys.argv[2]
except IndexError:
    print ("You need to specify a separator: tab (t) or space (s)")
    sys.exit(1)

sep = '\t'
if sys.argv[2] == 's':
    sep = ' '

df = pd.read_csv(sys.argv[1], header=0, index_col = None, sep=sep)
#file sig_lvls val1 eff1 both1 empty1 correct1 incorrect1 val1_err_0.02 val0 eff0 both0 empty0 correct0 incorrect0 val0_err_0.02
print (df)

try:
    filenames = df['file'].values.astype(str)
except:
    filenames = 'nan'

try:
    signlevels = df['sig_lvls'].values.astype(float)
except:
    signlevels = 'nan'

try:
    TN = df['correct0'].values.astype(float)
except:
    try:
        TN = df['corr0'].values.astype(float)
    except:
        TN = 'nan'

try:
    FP = df['incorrect0'].values.astype(float)
except:
    try:
        FP = df['incorr0'].values.astype(float)
    except:
        FP = 'nan'

try:
    FN = df['incorrect1'].values.astype(float)
except:
    try:
        FN = df['incorr1'].values.astype(float)
    except:
        FN = 'nan'

try:
    TP = df['correct1'].values.astype(float)
except:
    try:
        TP = df['corr1'].values.astype(float)
    except:
        TP = 'nan'


nrows = 1
output_file = sys.argv[1] +'_statistics.csv'
f = open(output_file, "w")

for filename, signlevel,tn,fp,fn,tp in zip(filenames,signlevels,TN,FP,FN,TP):
    perform_func(tn,fp,fn,tp,nrows, filename, signlevel)
    nrows = nrows + 1

f.close()
