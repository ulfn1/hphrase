"""
MIT License

Copyright (c) 2023 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


from typing import Dict

import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import AllChem
import sys


def calculate(molecules) -> np.ndarray:
        fingerprints = [_generate_fingerprint(query) for query in list(molecules)]
#        return np.asarray(fingerprints)
        return fingerprints

def _generate_fingerprint(query_smiles):
        try:
            fps = AllChem.GetMorganFingerprint(Chem.MolFromSmiles(query_smiles), 2, useChirality=True, useCounts=True)
            fps = _convert_to_hashed(fps, 1024)
        except:
            print(query_smiles)
            fps = 'XXX'
        return fps

def _convert_to_hashed(fingerprint, size):
        arr = np.zeros((size,), np.int32)
        for idx, v in fingerprint.GetNonzeroElements().items():
            nidx = idx % size
            arr[nidx] += int(v)
        return arr


################################## main ##################################33
try:
    sys.argv[1]
except IndexError:
    print ("You need to specify an input file")
    sys.exit(1)

#outfile =sys.argv[1]+".morgan4.txt"
outfile =sys.argv[1]+".morgan2.txt"

df = pd.read_csv(sys.argv[1],  sep='\t', header = 0, index_col = None)

try:
    df.rename(columns={"SMILES": "smiles", "dummy_std_smi": "smiles" }, inplace = True)
except:
    print ("No smiles column found")


df = df.drop(columns=['dummy_CAS EC Number'], axis=1, errors='ignore')



fps = df['smiles'].to_list() 

fps = calculate(fps)
dfmol = pd.DataFrame.from_records(fps)
dfmol = dfmol.add_prefix('morgan2_')
fps_nrows = dfmol.shape[0]
df_nrows = df.shape[0]

if df_nrows == fps_nrows:
    df = df.drop(columns=['smiles'], axis=1, errors='ignore')
    df = pd.concat([df, dfmol], axis=1)
    df = df.drop(['set'], axis=1, errors='ignore')
    df = df[(df.morgan2_0 != 'X') & (df.morgan2_1 != 'X') & (df.morgan2_2 != 'X')]
    print (df)
    df.to_csv(outfile, sep='\t', index=False, header=True)
else:
    print("input data and morgan4 fps have different number of rows:",df_nrows, fps_nrows)
    sys.exit(1)
