#!/usr/bin/perl

##############################################################################
# MIT License
#
# Copyright (c) 2023 Ulf Norinder
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
##############################################################################


my $unik = shift @ARGV;
my $unik2a = shift @ARGV;


if ($unik eq "") {
        print "You must give a tab separated nonconfomist p-value file\n";
        exit;
}

if ($unik2a eq "") {
        print "You must give a sign.level (0-1) for performance metrics (<0 for none)\n";
        exit;
}


$unik2 = 0.05;


for ($loop = 0; $loop <5; $loop++) {
	$unik2 = $unik2 + 0.05;
	@cmpds = ();
	$maxmodel = 0;
	
	open (IN,  "<$unik") || die "$0 cannot open Inputfile: $unik\n";
	while ($inline = <IN>) {
		chomp($inline);
		@arrayOneLine = split(/\t/,$inline);
		$aaa = int($arrayOneLine[3]);
#		print "$arrayOneLine[3]\t$aaa\n";
	        if ($arrayOneLine[3] ne $aaa) {
#			print "goto next\n";
			goto next;
		}
		push (@cmpds , $arrayOneLine[0]);
		$data{$arrayOneLine[0],cls} = $arrayOneLine[3];

	        if ($arrayOneLine[4] > $maxmodel) {
			 $maxmodel = $arrayOneLine[4];
		}
		$status = 0;
	        $p0 = $arrayOneLine[1];
	        $p1 = $arrayOneLine[2];

	        if ($p0 >= $unik2 and $p1 >= $unik2) {
			$data{$arrayOneLine[0],both} = $data{$arrayOneLine[0],both} + 1;
			$status = $status + 1;
		}
	        if ($p0 >= $unik2 and $p1 < $unik2) {
			$data{$arrayOneLine[0],cls0} = $data{$arrayOneLine[0],cls0} + 1;
			$status = $status + 1;
		}
	        if ($p0 < $unik2 and $p1 >= $unik2) {
			$data{$arrayOneLine[0],cls1} = $data{$arrayOneLine[0],cls1} + 1;
			$status = $status + 1;
		}
	        if ($p0 < $unik2 and $p1 < $unik2) {
			$data{$arrayOneLine[0],empty} = $data{$arrayOneLine[0],empty} + 1;
			$status = $status + 1;
		}

		if ($status < 1) {
			print "No status marking: $status\n";
 	 		exit;
		}
		if ($status > 1) {
			print "No status marking: $status\n";
			exit;
		}
	next:;
	}
	close IN;

	my @unique = do { my %seen; grep { !$seen{$_}++ } @cmpds };

	$val1 = 0;
	$val0 = 0;
	$eff1 = 0;
	$eff0 = 0;
	$numcls1 = 0;
	$numcls0 = 0;
	$corr1 = 0;
	$corr0 = 0;
	$both1 = 0;
	$both0 = 0;
	$incorr1 = 0;
	$incorr0 = 0;
	$empty1 = 0;
	$empty0 = 0;

	if ($unik2a eq $unik2) {
		open (OUT2, ">$unik\_pval_classification.csv.class_$unik2") || die "$0 cannot open Outputfile: $unik\_pval_classification.csv.class_$unik2\n";	
		print OUT2 "id\tclass\tpred_class\n";
	}
	foreach (@unique) {
		if ($data{$_,cls} eq 1) {
			$numcls1 = $numcls1 + 1;
		}
		if ($data{$_,cls} eq 0) {
			$numcls0 = $numcls0 + 1;
		}

		$max = 0;
		if ($data{$_,cls1} > $max) {
	                $max = $data{$_,cls1};
			$maxcls = "1";
		}
		if ($data{$_,cls0} > $max) {
	                $max = $data{$_,cls0};
			$maxcls = "0";
	 	}
		if ($data{$_,both} > $max) {
	                $max = $data{$_,both};
			$maxcls = "both";
		}
		if ($data{$_,empty} > $max) {
	                $max = $data{$_,empty};
			$maxcls = "empty";
		}

		$data{$_,result} = $maxcls;
		if ($unik2a eq $unik2) {
			print OUT2 "$_\t$data{$_,cls}\t$maxcls\n";
		}

	        if ($data{$_,result} eq 1 and $data{$_,cls} eq 1) {
			$val1 = $val1 + 1;
			$eff1 = $eff1 + 1;
			$corr1 = $corr1 + 1;
		}
	        if ($data{$_,result} eq 0 and $data{$_,cls} eq 1) {
			$eff1 = $eff1 + 1;
			$incorr1 = $incorr1 + 1;
		}
	        if ($data{$_,result} eq 0 and $data{$_,cls} eq 0) {
			$val0 = $val0 + 1;
			$eff0 = $eff0 + 1;
			$corr0 = $corr0 + 1;
		}
	        if ($data{$_,result} eq 1 and $data{$_,cls} eq 0) {
			$eff0 = $eff0 + 1;
			$incorr0 = $incorr0 + 1;
		}
	        if ($data{$_,result} eq "both" and $data{$_,cls} eq 1) {
			$val1 = $val1 + 1;
			$both1 = $both1 + 1;
		}
	        if ($data{$_,result} eq "both" and $data{$_,cls} eq 0) {
			$val0 = $val0 + 1;
			$both0 = $both0 + 1;
		}

	        if ($data{$_,result} eq "empty" and $data{$_,cls} eq 1) {
			$empty1 = $empty1 + 1;
		}
	        if ($data{$_,result} eq "empty" and $data{$_,cls} eq 0) {
			$empty0 = $empty0 + 1;
		}

        
		$data{$_,both} = 0;
		$data{$_,cls1} = 0;
		$data{$_,cls0} = 0;
		$data{$_,empty} = 0;
	}
	if ($unik2a eq $unik2) {
		close OUT2;
	}

	$val1 = $val1/$numcls1;
	$val0 = $val0/$numcls0;
	$eff1 = $eff1/$numcls1;
	$eff0 = $eff0/$numcls0;

	if ($loop == 0) {
		$mm = sprintf('%.01f',$maxmodel);
		open (OUT, ">$unik\_pval_classification.csv.val_eff_$mm") || die "$0 cannot open Outputfile: $unik\_pval_classification.csv.val_eff_$mm\n";	
		print OUT "file sig_lvls val1 eff1 both1 empty1 corr1 incorr1 val0 eff0 both0 empty0 corr0 incorr0\n";
		print "file sig_lvls val1 eff1 both1 empty1 corr1 incorr1 val0 eff0 both0 empty0 corr0 incorr0\n";
	}

	print "$unik $unik2 $val1 $eff1 $both1 $empty1 $corr1 $incorr1 $val0 $eff0 $both0 $empty0 $corr0 $incorr0 $numcls1 $numcls0\n";
	print OUT "$unik $unik2 $val1 $eff1 $both1 $empty1 $corr1 $incorr1 $val0 $eff0 $both0 $empty0 $corr0 $incorr0\n";
}

close OUT;
