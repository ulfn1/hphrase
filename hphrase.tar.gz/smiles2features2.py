"""
MIT License

Copyright (c) 2024 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""



# print ("//////////////////////////////////////// Run code using 'sa 3 hphrase' ////////////////////////////////////////")


import selfies
import deepsmiles
import sys
from collections import defaultdict, Counter
import pandas as pd
import numpy as np
from rdkit import Chem
import re

def ngramsfunc(comp_pat2,ngram):
    list_tot = []
    substr_len = len(comp_pat2)
    for element in range(substr_len-ngram+1):
        new_list = []
        for x in range(element, element+ngram):
            try:
                new_list.append(''.join(comp_pat2[x]))
            except:
                break
        list_tot.append(''.join(new_list))
    return(list_tot)


try:
    sys.argv[1]
except IndexError:
    print ("You need to specify a tab sep smiles input file (id, target, smiles)")
    sys.exit(1)
try:
    sys.argv[2]
except IndexError:
    print ("You need to specify header line (y) or not (n)")
    sys.exit(1)
try:
    sys.argv[3]
except IndexError:
    print ("You need to specify hashing length (<0 for no hashing")
    sys.exit(1)
try:
    sys.argv[4]
except IndexError:
    print ("You need to specify a reference file (0 to skip)")
    sys.exit(1)
try:
    sys.argv[5]
except IndexError:
    print ("You need to specify ngrams (n), selfies (s) or deepsmiles (d)")
    sys.exit(1)

try:
    sys.argv[6]
    lenngram = int(sys.argv[6])
    if sys.argv[5] == 'n':
        outfile =  sys.argv[1] + '_ngramsPE_' + sys.argv[6]
    if sys.argv[5] == 's':
        outfile =  sys.argv[1] + '_selfies_' + sys.argv[6]
    if sys.argv[5] == 'd':
        outfile =  sys.argv[1] + '_deepsmiles_' + sys.argv[6]

except IndexError:
    print ("You need to specify ngram length")
    sys.exit(1)


#smi = 'CC[N+](C)(C)Cc1ccccc1Br'


hashlen = int(sys.argv[3])
idescr = 0
vocab = Counter()
name = Counter()
data = defaultdict(int)
targetlist = []
notarget = 0
error_smiles = []

patterns =  "(\[[^\]]+]|Br?|Cl?|N|O|S|P|F|I|b|c|n|o|s|p|\(|\)|\.|=|#|-|\+|\\\\|\/|:|~|@|\?|>|\*|\$|\%[0-9]{2}|[0-9])"
#https://stackoverflow.com/questions/4697882/how-can-i-find-all-matches-to-a-regular-expression-in-python
print ("tokenizing ...")
with open(sys.argv[1], "r") as ins:
    if sys.argv[2] == 'y':
        ins.readline()
    for line in ins:
        line = line.strip()
        smi  = line.split('\t')[2]
        mol = Chem.MolFromSmiles(smi)
        if mol is None:
            print ("Error for smiles:", smi)
            error_smiles.append(smi)
        else:
            id  = line.split('\t')[0]
            try:
                target  = line.split('\t')[1]
                targetlist.append(target)

            except:
                notarget = 1
            id  = id.split('\n')[0]
            name[id] += 1
            if sys.argv[5] == 'n':
                comp_pat = re.compile(patterns)
                comp_pat2 = re.findall(comp_pat, smi)
                toks = ngramsfunc(comp_pat2,lenngram)

            if sys.argv[5] == 's':
                sel = selfies.encoder(smi)                
                comp_pat = re.compile(patterns)
                comp_pat2 = re.findall(comp_pat, sel)
                toks = ngramsfunc(comp_pat2,lenngram)

            if sys.argv[5] == 'd':
                converter = deepsmiles.Converter(rings=True, branches=True)
                deepsmi = converter.encode(smi)
                comp_pat = re.compile(patterns)
                comp_pat2 = re.findall(comp_pat, deepsmi)
                toks = ngramsfunc(comp_pat2,lenngram)

            str1 = ','.join(toks)
            ngrams = str1.split(',')
            for xx in ngrams:
                if vocab[xx] == 0:
                    idescr = idescr + 1
                    vocab[xx] = idescr
                data[id , xx] += 1

if notarget == 1:
    print ("/////////////// no target 3rd column found ///////////////")

print(f'{len(vocab)} unique ngrams')
print(f'{len(data)} data')
if len(vocab) > hashlen and hashlen > 0:
    print(hashlen)
    outfile =  outfile + '_hashed_' + str(hashlen) + '.txt' 
if len(vocab) <= hashlen or hashlen < 0:
    outfile =  outfile + '_' + str(len(vocab)) + '.txt' 

dferr = pd.DataFrame(error_smiles)
try:
    errfile = outfile + ".smi_errors"
    dferr.to_csv(errfile, sep='\t', index=False, header=True)
    numerr = dferr.shape[0]
    del dferr
except:
    pass


#
ngramname0 = ['']
ngramname = ['id']
ngramname2 = ['id']
if notarget == 0:
    ngramname2 = ['id','target']  

for key, value in vocab.items():
    sufix = int(value)%int(sys.argv[3])
    key2 = key + "_" + str(sufix)
    str0 = ''.join(key)
    str2 = ''.join(key2)
    ngramname.append(str0)
    ngramname2.append(str2)

df = pd.DataFrame(columns=ngramname)

namelist = []
for key, value in name.items():
    str0 = ''.join(str(key))
    namelist.append(str0)

df = df.drop(['id'], axis=1)
df2 = pd.concat([pd.DataFrame(namelist, columns=['id']),df], axis=1)

if notarget == 0:
    df3 = pd.DataFrame(targetlist, columns=['target'])
    df2 = pd.concat([df2, df3], axis = 1)

df2.set_index('id', drop=False, inplace=True)
del df
print ("zero filling")
df2.fillna(0, inplace=True, downcast='infer')

print ("key,value generation")
nDone=0
for key, value in data.items():
    str1 = ','.join(key)
    id  = str1.split(',')[0]
    ngram  = str1.split(',')[1]
    df2.at[id, ngram] = df2.at[id, ngram] + value
    nDone += 1
    if not nDone%1000: print("items done %d"%nDone)


cols = df2.columns.tolist()
cols = cols[-1:] + cols[:-1]
df2 = df2[cols]
tmpfile =  outfile + '_ref_' + str(len(vocab)) + '.ref_header'
df2.head(1).to_csv(tmpfile, sep = '\t', header=True, index=False, columns=None)

if sys.argv[4] != "0" and sys.argv[4] != outfile:
    df = pd.read_csv(sys.argv[4], index_col=False, header=0, nrows=1, sep = '\t')
    cols_ref = df.columns.tolist()
    if 'target'in df.columns:
        outfile =  outfile + '_ref_' + str(len(cols_ref)-2) + '.txt' 
    else:
        outfile =  outfile + '_ref_' + str(len(cols_ref)-1) + '.txt' 
    del df
    print ("reference columns\n", cols_ref)
    cols = list(set().union(df2.columns, cols_ref))
    df2 = df2.reindex(columns=cols, fill_value=0)

import warnings
warnings.filterwarnings("ignore")
df2['idx'] = df2.index
cols = df2.columns.tolist()
cols = cols[-1:] + cols[:-1]
df2 = df2[cols]
df2 = df2.drop(['id'], axis=1)
df2.rename(columns={'idx': 'id'}, inplace=True)

if sys.argv[4] != "0" and sys.argv[4] != outfile:
     df2 = df2[cols_ref]


#hashing if requested
if len(vocab) > hashlen and hashlen > 0:
    try:
        df0 = df2[['id', 'target']]
    except:
        df0 = df2[['id']]

    df2.columns=ngramname2
    df2 = df2.drop(columns=['id','idsplit', 'target'], axis=1, errors='ignore')
    ncols = df2.shape[1]
    nDone=0

    print ("hashing the features from",ncols, "to length:",hashlen,"...") 
    for isufix in range(int(sys.argv[3])):
        nDone += 1
        if not nDone%100: print("hashing columns done %d"%nDone)
        sufix = "_" + str(isufix)
        df2[str(isufix)] = df2[[col for col in df2.columns if col.endswith(sufix)]].sum(axis=1)

    df2 = df2.drop(df2.filter(regex='_').columns, axis=1)

    df2 = pd.concat([df0, df2], axis = 1)


print ("Writing to file -",outfile)
df2.to_csv(outfile, sep = '\t', header=True, index=False)

sys.exit(1)
