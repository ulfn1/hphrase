"""
MIT License

Copyright (c) 2023 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


from itertools import count
from string import ascii_lowercase
import sys
import pandas as pd
from rdkit import Chem


def letter_indexes(text):
#    letter_mapping = dict(zip(ascii_lowercase, count(1)))
# OBSERVE  \ in dictionary must be marked as \\ otherwise wrong assignment of numbers
    letter_mapping = {'a': 101, 'b': 102, 'c': 103, 'd': 104, 'e': 105, 'f': 106, 'g': 107, 'h': 108, 'i': 109, 'j': 110, 'k': 111, 'l': 112, 'm': 113, 'n': 114,
     'o': 115, 'p': 116, 'q': 117, 'r': 118, 's': 119, 't': 120, 'u': 121, 'v': 122, 'w': 123, 'x': 124, 'y': 125, 'z': 126 ,'A': 127, 'B': 128, 'C': 129,
     'D': 130, 'E': 131, 'F': 132, 'G': 133, 'H': 134, 'I': 135, 'J': 136, 'K': 137, 'L': 138, 'M': 139, 'N': 140,
     'O': 141, 'P': 142, 'Q': 143, 'R': 144, 'S': 145, 'T': 146, 'U': 147, 'V': 148, 'W': 149, 'X': 150, 'Y': 151, 'Z': 152 ,
     ' ': 153, '\\': 154, '/': 155, '.': 156 , '[': 157, ']': 158, '(': 159, ')': 160, '=': 161, '#': 162, '@': 163 ,
     '0': 164, '1': 165, '2': 166, '3': 167, '4':168, '5': 169, '6': 170, '7': 171, '8': 172 ,'9': 173 , '+': 174 , '-': 175 , '%': 176, '|': 177, ':': 178}


    indexes = [
      letter_mapping[letter] for letter in text  #.lower() 
      if letter in letter_mapping
    ]

    return ''.join(str(str(index).zfill(2)) for index in indexes)

#######################################################################



try:
    sys.argv[1]
except IndexError:
    print ("You need to specify an tab separarted input file (at least smiles id)")
    sys.exit(1)

try:
    sys.argv[2]
except IndexError:
    print ("You need to specify hash length")
    sys.exit(1)

try:
    sys.argv[3]
except IndexError:
    print ("You need to specify ngram length")
    sys.exit(1)

try:
    sys.argv[4]
except IndexError:
    print ("You need to specify header line or not (y/n)")
    sys.exit(1)

try:
    sys.argv[5]
except IndexError:
    print ("You need to specify id,smiles and target column number (comma sep, no space. starts with 0, <0 to skip)")
    sys.exit(1)

try:
    sys.argv[6]
except IndexError:
    print ("Precheck and remove erroneous smiles (y/n)")
    sys.exit(1)


increm = 0
sep = '\t'

cols = sys.argv[5].split(',')
idcol = int(cols[0])
smicol = int(cols[1])
targetcol = int(cols[2])
print (idcol, smicol, targetcol)

hashlen = int(sys.argv[2])
ngramlen = int(sys.argv[3])

if sys.argv[4] == 'y':
    df = pd.read_csv(sys.argv[1], sep=sep, header = 0, index_col = None)
else:
    df = pd.read_csv(sys.argv[1], sep=sep, header = None, index_col = None)

try:
    smiles = df['smiles']
except:
    df.rename(columns={ df.columns[smicol]: "smiles" }, inplace = True)
    print("/////////////////////// renaming column", smicol, "to 'smiles' ///////////////////////")

df.drop(df.iloc[:, 3:], inplace=True, axis=1)

print (df)

if sys.argv[6] == 'y':
    ckecked_smiles = []
    error_smiles = []
    for smiles in df.smiles:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            print ("Error for smiles:", smiles)
            error_smiles.append(smiles)
        else:
            ckecked_smiles.append(smiles)

#print (ckecked_smiles)

    dferr = df.query('smiles in @error_smiles')
    errfile = sys.argv[1] + '_ngram_' + str(ngramlen) + '_hashed_' + sys.argv[2]
    if sys.argv[6] == 'y':
        errfile = errfile + '_chk'
    errfile =errfile +".smi_errors"
    dferr.to_csv(errfile, sep='\t', index=False, header=True)
    numerr = dferr.shape[0]
    del dferr

    df = df.query('smiles in @ckecked_smiles')
    df.reset_index(drop=True, inplace=True)
    print (df)

nrows = df.shape[0]

df2 = pd.DataFrame()
df3 = pd.DataFrame()
df3['id'] = df.iloc[:, idcol]


if int(targetcol) >= 0:
    df3['target'] = df.iloc[:, int(targetcol)]

print(df3)

df2 = pd.DataFrame(index=range(nrows),columns=range(hashlen))
df2.fillna(value=0, inplace=True)
print ("Number of rows and columns:", df2.shape)

nDone=0
molerr = 0
errcount = 0
errstatus = 0
errname = 'nan'

for row in df.iloc[:, smicol].items():     #This is really stupid but I am lazy and it works for small files <24k with resonable compute speed
    id = int(row[0])
    row = str(row[1]).strip()
    nDone += 1
    if not nDone%1000: print(sys.argv[1],"- Done",nDone)
    if len(row) < ngramlen:
        for nlen in range(len(row),ngramlen):
            row = row + ' '

#    print ('##########',row, '#########')
    for nlen in range(ngramlen,ngramlen+1):
        for ii in range(len(row)-nlen+1):
            ngram = row[ii:(ii+nlen)]
            if ngram == "nan":
                print ("Empty ngram for:", id)
                errstatus = 1
            else:
                idxngram = letter_indexes(ngram)
                if len(idxngram) < 3*ngramlen:
                    errstatus = 1
                    if errname != id:
                        if errname != 'nan':
                            print ("Total errors for:", errname, errcount)
                        print ("Error ngram for:", id, len(idxngram), idxngram, ngram)
                        errname = id
                        errcount = 1
                    else:
                        errcount = errcount + 1
                else:
                    if errname != id and errname != 'nan':
                        print ("Total errors for:", errname, errcount)
                        errname = 'nan'
                    idxngram = int(idxngram)
                    if idxngram > 0:
                        hashed_ngram = idxngram%hashlen
                    df2.iloc[id, int(hashed_ngram)+increm] = df2.iloc[id, int(hashed_ngram)+increm] + 1

    if errstatus == 1:
        df2.iloc[id, :] = -10
    errstatus = 0

df2.columns = df2.columns.astype(str)
df2.columns = ['hashed_' + str(col) for col in df2.columns]

df2 = pd.concat([df3,df2], axis=1) #, join='inner')
df2.drop(df2[df2.hashed_0 < -5].index, inplace=True)
print (df2)

outfile = sys.argv[1] + '_ngram_' + str(ngramlen) + '_hashed_' + sys.argv[2]
if sys.argv[6] == 'y':
    outfile = outfile + '_chk'
    print ("Number of error smiles:", numerr)
outfile = outfile + '.txt'

print ("#std mol errors:",molerr)
print ("Writing to file -",outfile)
df2.to_csv(outfile, sep = '\t', header=True, index=False)

