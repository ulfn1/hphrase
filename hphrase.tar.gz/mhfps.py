"""
MIT License

Copyright (c) 2024 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import pandas as pd
import numpy as np
import rdkit
from rdkit import Chem
import sys

from mhfp.encoder import MHFPEncoder


################################## main ##################################33
try:
    sys.argv[1]
except IndexError:
    print ("You need to specify an input file")
    sys.exit(1)

try:
    sys.argv[2]
except IndexError:
    print ("You need to specify a secfp radius (even integers)")
    sys.exit(1)


fprad = float(sys.argv[2])
fprad = fprad/2
fprad = int(fprad)
outfile =sys.argv[1]+".secfp_" + sys.argv[2] + "_1024.txt"

df = pd.read_csv(sys.argv[1],  sep='\t', header = 0, index_col = None)

try:
    df['smiles'].values
    print (df)
except:
    print ("No smiles column found")
    sys.exit(1)

df = df.drop(columns=['dummy_CAS EC Number'], axis=1, errors='ignore')

ckecked_smiles = []
error_smiles = []
for smiles in df.smiles:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        print ("Error for smiles:", smiles)
        error_smiles.append(smiles)
    else:
        ckecked_smiles.append(smiles)


dferr = df.query('smiles in @error_smiles')
errfile =sys.argv[1]+".secfp_" + sys.argv[2] + "_1024.smi_errors"
dferr.to_csv(errfile, sep='\t', index=False, header=True)
numerr = dferr.shape[0]
del dferr

df = df.query('smiles in @ckecked_smiles')
df.reset_index(drop=True, inplace=True)


smi = df['smiles'].to_list() 

print ("MHFPEncoder.secfp_from_smiles ...")
fps = []
for i in smi:
    fp = MHFPEncoder.secfp_from_smiles(i,length=1024,radius=fprad) #secfp
    fps.append(fp)
dfmol = pd.DataFrame.from_records(fps)
print(dfmol)
dfmol = dfmol.add_prefix('secfp_')
fps_nrows = dfmol.shape[0]
df_nrows = df.shape[0]

if df_nrows == fps_nrows:
    df = df.drop(columns=['smiles'], axis=1, errors='ignore')
    df = pd.concat([df, dfmol], axis=1)
    df = df.drop(['set'], axis=1, errors='ignore')
    df = df[(df.secfp_0 != 'X') & (df.secfp_1 != 'X') & (df.secfp_2 != 'X')]
    print (df)
    df.to_csv(outfile, sep='\t', index=False, header=True)
else:
    print("input data and fps have different number of rows:",df_nrows, fps_nrows)
    sys.exit(1)
