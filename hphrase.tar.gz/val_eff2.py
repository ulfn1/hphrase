#!/usr/bin/env python

"""
MIT License

Copyright (c) 2023 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


from itertools import compress
import numpy as np
import os,sys
import pandas as pd

# configs
classes = [0,1] 
sig_lvls = [0.1, 0.15, 0.2, 0.25, 0.3]


#### Main ####

    
try:
    sys.argv[1]
except IndexError:
    print ("You need to specify an input tab sep file with p-values")
    sys.exit(1)

try:
    sys.argv[2]
except IndexError:
    print ("You need to specify an number of models to be used (<0 for all)")
    sys.exit(1)

try:
    sys.argv[3]
except IndexError:
    print ("You need to specify an ID separato to be used for second part (0 to skip)")
    sys.exit(1)

single_lvl = 0
try:
    sys.argv[4]
    sig_lvls0 = float(sys.argv[4])
    sig_lvls = abs(sig_lvls0)
    single_lvl = 1
except IndexError:
    print ("For a single signif level and prediction output you need to enter a value (>0 and <1, <0 for continous predictions)")

try:
    sys.argv[5]
except IndexError:
    print ("For a p-value output on examples enter (y)")

inpath = sys.argv[1]

compound_dict_id = {}
compound_dict_0 = {}
compound_dict_1 = {}
with open(inpath) as f:
    header = next(f)
    idx =  0
    for line in f:
        line = line.strip()
#        ID, label, raw0, raw1, sm0, sm1 = line.split("\t")
        ID, pos0, pos1, label, model  = line.split("\t")
#        ID, pred, pos0, pos1, dummy, label, model  = line.split("\t")
        try:
            pos0 = float(pos0)
        except:
            print("Error reading line:", line)
            line = next(f)
            line = line.strip()
            ID, pos0, pos1, label, model  = line.split("\t")
            
        if sys.argv[3] != "0":
            idparts = ID.split(sys.argv[3])
            if idparts[1] != "":
                ID = idparts[1]
            else:
                ID = idparts[0]

        repeat = 1
        idx =  idx + 1
        if idx % 1000000 == 0 and idx > 0: print ("done:",idx)

        try:
            compound_dict_id[ID]
        except:
            compound_dict_id[ID] = idx

        label = float(label)
        pos0 = float(pos0)
        pos1 = float(pos1)
        model = float(model)

        if model > int(sys.argv[2]) and int(sys.argv[2]) > 0:
            model = int(sys.argv[2])
            print ("Stopping after model",model)
            break

        if int(label) <= 0:
            try:
                compound_dict_0[ID].append([pos0, pos1])
            except:
                compound_dict_0[ID] = [[pos0, pos1]]
        else:
            try:
                compound_dict_1[ID].append([pos0, pos1])
            except:
                compound_dict_1[ID] = [[pos0, pos1]]

f.close()

# Calculate the performance at the set sig_lvls
inpath = sys.argv[1] + '.val_eff' + '_' + str(model)

while True:
    if single_lvl == 1:
        inpath = sys.argv[1] + '.val_eff_' + str(sig_lvls) + '_' + str(model)
        inpath2 = sys.argv[1] + '.conf_pred_results_median_class_' + str(sig_lvls) + '_' + str(model)
        sig_lvls = [sig_lvls]

    compound_tot = []
    f = open(inpath,"w")

    print("file sig_lvls val1 eff1 both1 empty1 correct1 incorrect1 val0 eff0 both0 empty0 correct0 incorrect0")
    f.write("file sig_lvls val1 eff1 both1 empty1 correct1 incorrect1 val0 eff0 both0 empty0 correct0 incorrect0\n")

    for sig in sig_lvls:
    
        # Calculate stats for class 1
        both1 = 0
        empty1 = 0
        correct1 = 0
        incorrect1 = 0
        label = 1
        for key in compound_dict_1:
    
            c0 = (True if np.median(compound_dict_1[key], axis=0)[0] >= abs(sig) else False)
            c1 = (True if np.median(compound_dict_1[key], axis=0)[1] >= abs(sig) else False)
            pred_class = list(compress(classes,[c0,c1]))
        
            if len(pred_class) == 0:
                empty1+=1
                predlabel = 'empty'
            elif len(pred_class) == 2:
                both1+=1
                predlabel = 'both'
            else:
                if pred_class[0] == 1:
                    correct1+=1
                    predlabel = '1'
                else:
                    incorrect1+=1
                    predlabel = '0'

            if single_lvl == 1:
                aa =  key + '\t' + str(label) + '\t' + str(np.median(compound_dict_1[key], axis=0)[0]) + '\t' + str(np.median(compound_dict_1[key], axis=0)[1]) + '\t' + str(predlabel)  + '\t' + str(compound_dict_id[key]) + '\n'
                compound_tot.append(aa)
    
        # Calculate stats for class 0
        both0 = 0
        empty0 = 0
        correct0 = 0
        incorrect0 = 0
        label = 0
        for key in compound_dict_0:
    
            c0 = (True if np.median(compound_dict_0[key], axis=0)[0] >= abs(sig) else False)
            c1 = (True if np.median(compound_dict_0[key], axis=0)[1] >= abs(sig) else False)
            pred_class = list(compress(classes,[c0,c1]))
        
            if len(pred_class) == 0:
                empty0+=1
                predlabel = 'empty'
            elif len(pred_class) == 2:
                both0+=1
                predlabel = 'both'
            else:
                if pred_class[0] == 0:
                    correct0+=1
                    predlabel = '0'
                else:
                    incorrect0+=1
                    predlabel = '1'
    
            if single_lvl == 1:
                aa =  key + '\t' + str(label) + '\t' + str(np.median(compound_dict_0[key], axis=0)[0]) + '\t' + str(np.median(compound_dict_0[key], axis=0)[1]) + '\t' + str(predlabel)  + '\t' + str(compound_dict_id[key]) # + '\n'
                compound_tot.append(aa)
 

        val1 = "NA"
        eff1 = "NA"
        val0 = "NA"
        eff0 = "NA"

        if (incorrect1+empty1+correct1+both1) > 0:
            val1 = (correct1+both1)/(incorrect1+empty1+correct1+both1)
            eff1 = (correct1+incorrect1)/((incorrect1+empty1+correct1+both1))
        if (incorrect0+empty0+correct0+both0) > 0:
            val0 = (correct0+both0)/(incorrect0+empty0+correct0+both0)
            eff0 = (correct0+incorrect0)/((incorrect0+empty0+correct0+both0)) 

        print(inpath, sig, val1, eff1, both1, empty1, correct1, incorrect1, val0, eff0, both0, empty0, correct0, incorrect0)
        aa = inpath + ' ' + str(sig) + ' ' + str(val1) + ' ' + str(eff1) + ' ' + str(both1) + ' ' + str(empty1) + ' ' + str(correct1) + ' ' + str(incorrect1) + ' ' + str(val0) + ' ' + str(eff0) + ' ' + str(both0) + ' ' + str(empty0) + ' ' + str(correct0) + ' ' + str(incorrect0) + '\n'
        f.write(aa)
        f.flush()

    f.close()
    if single_lvl == 1:
        try:
            sys.argv[5]
            df = pd.DataFrame({"Col": compound_tot})
            print(df)
            df = df.pop('Col').str.split('\t',expand=True)
            print(df)
            cols = ['id','label','p0','p1','pred_class','order']
            df.columns = cols
            df = df.astype({"order": int})
            df = df.sort_values(by=['order'], ascending=True)
            df = df.drop(['order'], axis=1, errors='ignore')
            df.to_csv(inpath2, sep = '\t', header=True, index=False) 
        except IndexError:
            try:
                sys.argv[5]
            except IndexError:
                print("Something went wrong in writing file:",inpath2)
                dummy = 1

    if single_lvl == 0:
        sys.exit(1)

    if single_lvl == 1 and float(sig_lvls0) < 0:
        sig_lvls0 = input("enter a value (>0 and <1, <0 for continous predictions, 0 to quit): ")
        try:
            sig_lvls = abs(float(sig_lvls0))
        except:
            sig_lvls0 = input("enter a value (>0 and <1, <0 for continous predictions, 0 to quit): ")

    if float(sig_lvls0) >= 0 and single_lvl == 1:
        sys.exit(1)
