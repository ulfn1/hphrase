"""
MIT License

Copyright (c) 2024 Ulf Norinder

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""



print ("//////////////////////////////////////// Run code using 'sa 3 csfp' ////////////////////////////////////////")

from rdkit import Chem
import numpy as np
import pandas as pd
from fingerprintGenerator import FragmentFingerprint
import sys

try:
    sys.argv[1]
except IndexError:
    print ("You need to specify an input file")
    sys.exit(1)


df = pd.read_csv(sys.argv[1],  sep='\t', header = 0, index_col = None)

try:
    df.rename(columns={"SMILES": "smiles", "dummy_std_smi": "smiles" }, inplace = True)
except:
    print ("No smiles column found")


df = df.drop(columns=['dummy_CAS EC Number'], axis=1, errors='ignore')



#smartsCSFP.csv from https://github.com/f48r1/TISBE/tree/main/data
SMARTS=np.loadtxt("smartsCSFP.csv", delimiter = "_", dtype=str, comments=None, usecols=[0])
CSFP=FragmentFingerprint(substructure_list=SMARTS)
print (CSFP.n_bits)

ckecked_smiles = []
error_smiles = []
for smiles in df.smiles:
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        print ("Error for smiles:", smiles)
        error_smiles.append(smiles)
    else:
        ckecked_smiles.append(smiles)

#print (ckecked_smiles)

dferr = df.query('smiles in @error_smiles')
errfile =sys.argv[1]+"_csfp.smi_errors"
dferr.to_csv(errfile, sep='\t', index=False, header=True)
numerr = dferr.shape[0]
del dferr

df = df.query('smiles in @ckecked_smiles')
df.reset_index(drop=True, inplace=True)
print (df)

tmp = CSFP.transform_smiles(df.smiles)
fps = pd.DataFrame.sparse.from_spmatrix(tmp)
outfile =sys.argv[1]+"_csfp.txt"


print (fps)

fps_nrows = fps.shape[0]
df_nrows = df.shape[0]


if df_nrows == fps_nrows:
    df = df.drop(columns=['smiles'], axis=1, errors='ignore')
    df = pd.concat([df, fps], axis=1)
    print (df)
    df.to_csv(outfile, sep='\t', index=False, header=True)
    print ("Number of error smiles:", numerr)
else:
    print("input data and csfp fps have different number of rows:",df_nrows, fps_nrows)
    sys.exit(1)

